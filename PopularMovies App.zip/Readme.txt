PopularMovies app stage 1.
API key should be added to the String variable 'key' in Class 'AuthKey'.