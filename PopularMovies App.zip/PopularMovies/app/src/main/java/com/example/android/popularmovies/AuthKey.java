package com.example.android.popularmovies;

/**
 * Created by aravindHP on 05-Jul-17.
 */

class AuthKey {
    public static final String key="";

}
