package com.example.android.popularmovies;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class MovieActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie);

        Intent movieIntent=getIntent();
        Movie movie= (Movie) movieIntent.getSerializableExtra("movie");

        TextView movieTitle;
        ImageView moviePoster;
        TextView movieRating;
        TextView movieOriginalTitle;
        TextView movieReleaseDate;
        TextView movieOverview;

        movieTitle= (TextView) findViewById(R.id.movie_title);
        movieTitle.setText(movie.getTitle());

        moviePoster= (ImageView) findViewById(R.id.movie_poster);
        Picasso.with(this).load("https://image.tmdb.org/t/p/w342" +movie.getPosterPath()).placeholder(R.drawable.user_placeholder).error(R.drawable.user_placeholder_error).into(moviePoster);

        movieRating= (TextView) findViewById(R.id.movie_rating);
        movieRating.setText(Float.toString(movie.getVoteAverage()));

        movieOriginalTitle= (TextView) findViewById(R.id.movie_original_title);
        movieOriginalTitle.setText("Original title : "+movie.getOriginalTitle());

        movieReleaseDate= (TextView) findViewById(R.id.movie_release_date);
        movieReleaseDate.setText("Release date : "+movie.getReleaseDate());

        movieOverview= (TextView) findViewById(R.id.movie_overview);
        movieOverview.setText(movie.getOverview());


    }
}
