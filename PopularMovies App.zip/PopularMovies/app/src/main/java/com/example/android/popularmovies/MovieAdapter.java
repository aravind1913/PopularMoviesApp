package com.example.android.popularmovies;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by aravindHP on 05-Jul-17.
 */

class MovieAdapter extends ArrayAdapter<Movie> {

    ArrayList<Movie> movieArrayList;
    Context context;

    public MovieAdapter(@NonNull Context context, ArrayList<Movie> movieArrayList) {
        super(context, 0,movieArrayList);
        this.movieArrayList=movieArrayList;
        this.context=context;
    }



    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent){
        Movie movie=getItem(position);

        if(convertView==null)
        {
            convertView= LayoutInflater.from(getContext()).inflate(R.layout.thumb_list, parent, false);
        }

        ImageView movieThumb= (ImageView) convertView.findViewById(R.id.movie_thumb);
        Picasso.with(getContext()).load("https://image.tmdb.org/t/p/w185" +movie.getPosterPath()).into(movieThumb);

        return convertView;
    }
}
