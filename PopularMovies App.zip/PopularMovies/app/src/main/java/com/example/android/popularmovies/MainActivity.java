package com.example.android.popularmovies;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    GridView gridView;
    ArrayList<Movie> movieArrayList;
    String sortType;

    SharedPreferences sharedPreferences;

       @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

           sharedPreferences = this.getPreferences(Context.MODE_PRIVATE);
           sortType=sharedPreferences.getString("sortType","popular");

        gridView = (GridView) findViewById(R.id.movie_list_GV);
        if(NetworkUtilities.networkCheck(MainActivity.this))
        {
            new LoadDataAsyncTask().execute(sortType);
        }
        else {
            Toast toast = Toast.makeText(MainActivity.this, "No internet connection", Toast.LENGTH_SHORT);
            toast.show();
        }
        gridView.setOnItemClickListener(MainActivity.this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.settings_menu,menu);
        //LayoutInflater li=LayoutInflater.from(MainActivity.this);
        //View v=li.inflate(R.layout.sort_by_radio,null,false);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        SharedPreferences.Editor editor=sharedPreferences.edit();
        if(item.getItemId()==R.id.sort_popular){
            sortType= "popular";
            editor.putString("sortType",sortType);
            editor.commit();
            if(NetworkUtilities.networkCheck(MainActivity.this))
            {
                new LoadDataAsyncTask().execute(sortType);
            }
            else {
                Toast toast = Toast.makeText(MainActivity.this, "No internet connection", Toast.LENGTH_SHORT);
                toast.show();
            }
        }
        else if(item.getItemId()==R.id.sort_rated)
        {
            sortType="top_rated";
            editor.putString("sortType",sortType);
            editor.commit();
            if(NetworkUtilities.networkCheck(MainActivity.this))
            {
                new LoadDataAsyncTask().execute(sortType);
            }
            else {
                Toast toast = Toast.makeText(MainActivity.this, "No internet connection", Toast.LENGTH_SHORT);
                toast.show();
            }
        }
        return true;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Movie movie= (Movie) parent.getAdapter().getItem(position);
        Intent movieIntent=new Intent(MainActivity.this, MovieActivity.class);
        movieIntent.putExtra("movie",movie);
        startActivity(movieIntent);
    }


    public class LoadDataAsyncTask extends AsyncTask<String, Void, Void>{

       @Override
        protected Void doInBackground(String... sortType) {
            String searchString;
            searchString="http://api.themoviedb.org/3/movie/"+ sortType[0] +"?api_key="+AuthKey.key;

            movieArrayList =new ArrayList<>();

            try {
                movieArrayList =getJSONData(searchString, movieArrayList);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void  s) {
            super.onPostExecute(s);
            MovieAdapter newAdapter=new MovieAdapter(MainActivity.this, movieArrayList);
            gridView.setAdapter(newAdapter);
        }
    }

    private ArrayList<Movie> getJSONData(String URLString, ArrayList<Movie> arrayList) throws MalformedURLException {

        URL url=new URL(URLString);
        try {
            HttpURLConnection urlConnection= (HttpURLConnection) url.openConnection();
            InputStream inputStream=urlConnection.getInputStream();

            Scanner scanner = new Scanner(inputStream);
            scanner.useDelimiter("\\A");
            String JSONResultString;
            if(scanner.hasNext())
            {
                JSONResultString=scanner.next();
            }
            else
                JSONResultString=null;


            return JSONParser(JSONResultString, arrayList);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private ArrayList<Movie> JSONParser(String jsonResultString, ArrayList<Movie> arrayList) {
        try {
            JSONObject listResult=new JSONObject(jsonResultString);
            JSONArray moviesArray=listResult.getJSONArray("results");
            for(int i=0; i<moviesArray.length(); i++)
            {
                JSONObject currentJSON=moviesArray.getJSONObject(i);
                Movie currentMovie=new Movie();
                currentMovie.setTitle(currentJSON.getString("title"));
                currentMovie.setOriginalTitle(currentJSON.getString("original_title"));
                currentMovie.setPosterPath(currentJSON.getString("poster_path"));
                currentMovie.setOverview(currentJSON.getString("overview"));
                currentMovie.setVoteAverage(currentJSON.getInt("vote_average"));
                currentMovie.setReleaseDate(currentJSON.getString("release_date"));
                arrayList.add(currentMovie);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    return arrayList;
    }
}
