package com.example.android.popularmovies;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

/**
 * Created by aravindHP on 05-Jul-17.
 */

class NetworkUtilities {

    public static boolean networkCheck(Context context)
    {
        ConnectivityManager connectivityManager= (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo=connectivityManager.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnected();
    }
/*
    @Override
    public void onReceive(Context context, Intent intent) {
        if(networkCheck(context))
        {
            new MainActivity.LoadDataAsyncTask().execute();
        }
    }*/
}
